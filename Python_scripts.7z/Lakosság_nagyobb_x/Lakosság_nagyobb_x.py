from qgis.PyQt.QtWidgets import QInputDialog

layer = QgsProject.instance().mapLayersByName('countries')[0]

population_limit, ok = QInputDialog.getInt(None, 'Lakossági Limit', 'Adja meg a városok lakossági limitjét:', 0, 0)

if ok:
    expression = QgsExpression('"POP_EST" > {}'.format(population_limit))

    selection = layer.getFeatures(QgsFeatureRequest(expression))
    layer.selectByIds([feature.id() for feature in selection])
