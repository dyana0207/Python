from qgis.PyQt.QtWidgets import QAction, QToolBar, QPushButton, QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt
from qgis.core import QgsRasterBandStats

def show_statistics():
    layer = iface.activeLayer()
    print(layer)
    if not layer or layer.type() != QgsMapLayer.RasterLayer:
        QMessageBox.warning(None, 'Raszter statisztika', 'Nincs kiválasztva vagy nincs aktív raszter réteg.')
        return

    extent = iface.mapCanvas().extent()

    provider = layer.dataProvider()
    stats = provider.bandStatistics(1, QgsRasterBandStats.All, extent)

    if stats:
        average_height = stats.mean
        print(average_height)
        message = f"Az átlagos magasság az aktuális kiterjedésben: {average_height:.2f}"
        iface.messageBar().pushInfo("Raszter statisztika", message)
    else:
        iface.messageBar().pushWarning("Raszter statisztika", "Nem sikerült számolni a raszterstatisztikát.")

icon_path = 'C:/Users/diana/Desktop/Suli/szakdoga/Domborzat statisztika/statistic'
action = QAction('Statisztika')
action.triggered.connect(show_statistics)
action.setIcon(QIcon(icon_path))
iface.addToolBarIcon(action)