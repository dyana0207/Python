layer = QgsProject.instance().mapLayersByName('rivers')[0]
fields = layer.fields()
count=0

with edit(layer):
    for feature in layer.getFeatures():
        attributes = feature.attributes()
        feature_count = layer.featureCount()
        count+=1
        for index, value in enumerate(attributes):
            if value==NULL:
                if fields[index].isNumeric() and index==0:
                    attributes[index] = count
                elif fields[index].isNumeric():
                    attributes[index] = 0
                elif not fields[index].isNumeric():
                    attributes[index] = 'N/A'
        feature.setAttributes(attributes)
        layer.updateFeature(feature)