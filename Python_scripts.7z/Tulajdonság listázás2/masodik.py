layer = iface.activeLayer()

if layer.type() == QgsMapLayer.VectorLayer:
    layer.selectAll()
    selected_features = layer.selectedFeatures()
    for feature in selected_features:
        print("Azonosító:", feature.id())
        print("Tulajdonságok:")
        for field in feature.fields():
            print(f"{field.name()}: {feature[field.name()]}")
        print("\n")
else:
    print("A réteg nem vektoros réteg.")