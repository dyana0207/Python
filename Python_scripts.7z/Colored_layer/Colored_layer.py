from qgis.core import QgsProject, QgsSymbol, QgsSymbolLayerRegistry

layer_name = 'Colored_layer'
attribute_name = 'NAME_1'

category_styles = {
    'Bács-Kiskun': '#440f2b',
    'Békés': '#134f5c',
    'Baranya': '#089bcc',
    'Borsod-Abaúj-Zemplén': '#f23869',
    'Budapest': '#fdf1bc',
    'Csongrád': '#008000',
    'Fejér': '#e7c590',
    'Gyor-Moson-Sopron': '#cf9259',
    'Hajdú-Bihar': '#d51b21',
    'Heves': '#fa6607',
    'Jász-Nagykun-Szolnok': '#00c2c4',
    'Komárom-Esztergom': '#575a65',
    'Nógrád': '#d9d9d9',
    'Pest': '#aec3b0',
    'Somogy': '##1985a1',
    'Szabolcs-Szatmár-Bereg': '#e5c54f',
    'Tolna': '#ffc2c2',
    'Vas': '#ffa733',
    'Veszprém': '#4666ff',
    'Zala': '#e1ceff'
}

layer = QgsProject.instance().mapLayersByName("HUN_adm2")[0] 


categories = []
for category, color in category_styles.items():
    symbol = QgsSymbol.defaultSymbol(layer.geometryType())
    symbol_layer = symbol.symbolLayer(0)
    if symbol_layer is None:
        symbol_layer = QgsSymbolLayerRegistry.instance().symbolLayerMetadata('SimpleFill').createSymbolLayer({'color': color})
        symbol.changeSymbolLayer(0, symbol_layer)
    else:
        symbol_layer.setColor(QColor(color))
        category = QgsRendererCategory(category, symbol, str(category))
        categories.append(category)

category_renderer = QgsCategorizedSymbolRenderer(attribute_name, categories)
layer.setRenderer(category_renderer)
layer.triggerRepaint()

print("Stílusok beállítva.")

