from qgis.core import QgsProcessingFeatureSourceDefinition, QgsProcessingAlgorithm, QgsProcessingParameterFeatureSource, QgsProcessingParameterFeatureSink, QgsProcessingOutputVectorLayer, QgsProcessingContext
import processing

layer = QgsProject.instance().mapLayersByName('MyPoints')[0]
buffer_distance_meters = 5  
input_layer = QgsProcessingFeatureSourceDefinition(layer.source(), selectedFeaturesOnly=False)
output_layer = 'memory:'
params = {
    'INPUT': input_layer,
    'DISTANCE': buffer_distance_meters,
    'SEGMENTS': 5,
    'END_CAP_STYLE': 0,
    'JOIN_STYLE': 0,
    'MITER_LIMIT': 10,
    'DISSOLVE': False,
    'OUTPUT': output_layer
}
result = processing.run("native:buffer", params)

if result and 'OUTPUT' in result and result['OUTPUT']:
    buffer_layer = result['OUTPUT']
    QgsProject.instance().addMapLayer(buffer_layer)
else:
    print('A buffer feldolgozási algoritmus nem hozott eredményt.')