from qgis.core import QgsVectorLayer, QgsFeatureRequest, QgsGeometry
from qgis.PyQt.QtWidgets import QLabel, QPushButton, QComboBox
from qgis.PyQt.QtGui import QColor

world_countries_layer = QgsProject.instance().mapLayersByName('countries')[0]
crsToolbar = iface.addToolBar('CRS Toolbar')
label = QLabel('Válassz egy országot', parent=crsToolbar)
button = QPushButton('Go!', parent=crsToolbar)
countryComboBox = QComboBox(parent=crsToolbar)

for feature in world_countries_layer.getFeatures(QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)):
    countryComboBox.addItem(feature.attribute('NAME'), feature.id())


crsToolbar.addWidget(label)
crsToolbar.addWidget(countryComboBox)
crsToolbar.addWidget(button)

def changeCrs():
    selected_country_id = countryComboBox.currentData()
    selected_country_feature = world_countries_layer.getFeature(selected_country_id)
    world_countries_layer.removeSelection()
    world_countries_layer.selectByIds([selected_country_id])
    iface.mapCanvas().refresh()
    
button.clicked.connect(changeCrs)