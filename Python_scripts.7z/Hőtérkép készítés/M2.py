
vl = iface.mapCanvas().layer(0)
cloned_layer = iface.addVectorLayer(vl.source(), vl.name() + "_clone", vl.providerType())

heatmap_renderer = QgsHeatmapRenderer()
heatmap_renderer.setWeightExpression('1')
heatmap_renderer.setRadius(5)

cloned_layer.setRenderer(heatmap_renderer)
cloned_layer.triggerRepaint()