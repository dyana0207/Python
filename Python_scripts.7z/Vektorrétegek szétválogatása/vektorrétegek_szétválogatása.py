from qgis.core import QgsVectorLayer, QgsFeature

layer1=QgsProject.instance().mapLayersByName('point_county')[0]
layer2=QgsProject.instance().mapLayersByName('place_county')[0]
layer3 = QgsVectorLayer("Point?crs=EPSG:4326", "Output", "memory")

values2=set(feature["name"] for feature in layer2.getFeatures())

layer3.startEditing()
for field in layer1.fields():
    layer3.addAttribute(QgsField(field.name(), field.type()))

for feature in layer1.getFeatures():
    if feature["place"] == "county" and feature["name"] in values2:
        new_feature = QgsFeature(layer3.fields())
        new_feature.setAttributes(feature.attributes())
        new_feature.setGeometry(feature.geometry())
        layer3.addFeature(new_feature)

    
layer3.commitChanges()
QgsProject.instance().addMapLayer(layer3)