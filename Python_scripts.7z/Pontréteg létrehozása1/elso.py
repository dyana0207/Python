from qgis.core import QgsVectorLayer, QgsPointXY, QgsFeature, QgsGeometry, QgsProject

layer = QgsVectorLayer("Point?crs=EPSG:4326", "MyPoints", "memory")
pr = layer.dataProvider()

points = [QgsPointXY(-90, 40),
            QgsPointXY(-85, 20),
                QgsPointXY(-80, 50)]
for point in points:
    feature = QgsFeature()
    feature.setGeometry(QgsGeometry.fromPointXY(point))
    pr.addFeature(feature)

QgsProject.instance().addMapLayer(layer)
