from geopy.geocoders import Nominatim

address = "Debrecen, Kassai út 26"
geolocator = Nominatim(user_agent="my_app")
location = geolocator.geocode(address)

latitude = location.latitude
longitude = location.longitude

print(f"Cím: {address}")
print(f"Koordináták: ({latitude}, {longitude})")
