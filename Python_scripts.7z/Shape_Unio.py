import random
from qgis.core import QgsGeometry, QgsFeature, QgsVectorLayer, QgsPointXY

def shape_type():
    return random.randint(3,7)

def generate_random_polygon(bbox):
    number_of_point=shape_type()
    points=[]
    print(number_of_point)
    for i in range(number_of_point):
        x = random.uniform(0, 100)
        y = random.uniform(0, 100)
        points.append(QgsPointXY(x, y))
    points.append(points[0])
    return QgsGeometry.fromPolygonXY([points])

bbox = (0, 0, 100, 100)

polygon1 = generate_random_polygon(bbox)
polygon2 = generate_random_polygon(bbox)
print("A két poligon")
print(polygon1)
print(polygon2)

layer1 = QgsVectorLayer("Polygon?crs=EPSG:4326", "Polygon 1", "memory")
layer2 = QgsVectorLayer("Polygon?crs=EPSG:4326", "Polygon 2", "memory")

feature = QgsFeature()
feature.setGeometry(polygon1)
layer1.dataProvider().addFeatures([feature])

feature = QgsFeature()
feature.setGeometry(polygon2)
layer2.dataProvider().addFeatures([feature])

layers = [layer1, layer2]

output_layer = QgsVectorLayer("Polygon?crs=epsg:4326", "Unio", "memory")
output_layer_data_provider = output_layer.dataProvider()
for current_layer in layers:
    output_layer_data_provider.addFeatures(current_layer.getFeatures())

QgsProject.instance().addMapLayer(layer1)
QgsProject.instance().addMapLayer(layer2)
QgsProject.instance().addMapLayer(output_layer)

iface.mapCanvas().refresh()